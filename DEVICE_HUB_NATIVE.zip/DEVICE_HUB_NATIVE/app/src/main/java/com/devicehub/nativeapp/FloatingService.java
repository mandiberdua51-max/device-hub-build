package com.devicehub.nativeapp;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.drawable.GradientDrawable;

public class FloatingService extends Service {
    private WindowManager wm;
    private View panel;
    private WindowManager.LayoutParams params;
    private float downX, downY;
    private int startX, startY;
    @Override public IBinder onBind(Intent intent) { return null; }
    @Override public void onCreate() { super.onCreate(); showPanel(); }
    @Override public int onStartCommand(Intent intent, int flags, int startId) { if (panel == null) showPanel(); return START_NOT_STICKY; }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density); }
    private void showPanel() {
        if (!Settings.canDrawOverlays(this) || panel != null) return;
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(14), dp(10), dp(14), dp(12));
        GradientDrawable bg = new GradientDrawable(); bg.setColor(Color.rgb(17,29,49)); bg.setCornerRadius(dp(18)); bg.setStroke(dp(1), Color.rgb(90,135,190)); card.setBackground(bg);
        LinearLayout header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this); title.setText("DEVICE HUB MINI"); title.setTextColor(Color.WHITE); title.setTypeface(Typeface.DEFAULT, Typeface.BOLD); title.setTextSize(14);
        header.addView(title, new LinearLayout.LayoutParams(0, dp(38), 1));
        Button close = new Button(this); close.setText("×"); close.setTextSize(20); close.setTextColor(Color.WHITE); close.setBackgroundColor(Color.TRANSPARENT);
        header.addView(close, new LinearLayout.LayoutParams(dp(42), dp(38))); card.addView(header);
        TextView state = new TextView(this); state.setText("STATUS PERANGKAT\nONLINE"); state.setTextColor(Color.WHITE); state.setTextSize(19); state.setPadding(0,dp(8),0,dp(4)); card.addView(state);
        TextView note = new TextView(this); note.setText("Panel mengambang Android aktif"); note.setTextColor(Color.LTGRAY); note.setTextSize(12); card.addView(note);
        Button hide = new Button(this); hide.setText("Tutup panel"); hide.setAllCaps(false); card.addView(hide);
        close.setOnClickListener(v -> stopSelf()); hide.setOnClickListener(v -> stopSelf());
        header.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) { downX=event.getRawX(); downY=event.getRawY(); startX=params.x; startY=params.y; return true; }
            if (event.getAction() == MotionEvent.ACTION_MOVE) { params.x=startX+(int)(event.getRawX()-downX); params.y=startY+(int)(event.getRawY()-downY); try { wm.updateViewLayout(panel,params); } catch(Exception ignored){} return true; }
            return true;
        });
        int type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        params = new WindowManager.LayoutParams(dp(270), WindowManager.LayoutParams.WRAP_CONTENT, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.END; params.x=dp(16); params.y=dp(120);
        panel = card;
        try { wm.addView(panel, params); } catch (Exception e) { panel=null; stopSelf(); }
    }
    @Override public void onDestroy() { if (wm != null && panel != null) { try { wm.removeView(panel); } catch(Exception ignored){} } panel=null; super.onDestroy(); }
}
