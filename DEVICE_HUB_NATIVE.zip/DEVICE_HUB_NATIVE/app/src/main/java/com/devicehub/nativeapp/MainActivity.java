package com.devicehub.nativeapp;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private EditText apiKeyInput, appIdInput, emailInput, passwordInput, aliasInput;
    private TextView status;
    private android.content.SharedPreferences prefs;
    private FirebaseAuth auth;
    private DatabaseReference userPrefs;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("devicehub", MODE_PRIVATE);
        buildUi();
        loadSaved();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density); }
    private TextView text(String value, int size, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(Color.WHITE);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(0, dp(8), 0, dp(8)); return t;
    }
    private EditText field(String hint) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setHint(hint); e.setTextColor(Color.WHITE);
        e.setHintTextColor(Color.LTGRAY); e.setTextSize(15); e.setPadding(dp(12), dp(8), dp(12), dp(8));
        e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(80, 110, 150)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(52)); lp.bottomMargin = dp(8); e.setLayoutParams(lp); return e;
    }
    private Button button(String label) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(38, 67, 103)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(50)); lp.bottomMargin = dp(8); b.setLayoutParams(lp); return b;
    }
    private void buildUi() {
        ScrollView scroll = new ScrollView(this); scroll.setBackgroundColor(Color.rgb(10,16,32));
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(20), dp(20), dp(20), dp(28));
        scroll.addView(root); setContentView(scroll);
        root.addView(text("DEVICE HUB", 28, true));
        root.addView(text("Android native • Floating Window • Firebase Sync", 14, false));
        root.addView(text("1. KONFIGURASI FIREBASE WEB", 17, true));
        root.addView(text("Salin nilai apiKey dan appId lengkap dari Firebase Console → Project settings → Your apps → DEVICE HUB WEB → Config. Project ID dan Database URL sudah diisi.", 13, false));
        apiKeyInput = field("apiKey Firebase"); root.addView(apiKeyInput);
        appIdInput = field("appId Firebase"); root.addView(appIdInput);
        Button connect = button("Simpan konfigurasi & hubungkan Firebase"); root.addView(connect);
        connect.setOnClickListener(v -> connectFirebase());
        root.addView(text("2. AKUN FIREBASE", 17, true));
        emailInput = field("Email akun Firebase"); root.addView(emailInput);
        passwordInput = field("Kata sandi"); passwordInput.setInputType(129); root.addView(passwordInput);
        Button create = button("Buat akun baru"); root.addView(create);
        create.setOnClickListener(v -> signUp());
        Button login = button("Login"); root.addView(login);
        login.setOnClickListener(v -> login());
        root.addView(text("3. FLOATING WINDOW ANDROID", 17, true));
        root.addView(text("Panel ini dapat tampil di atas aplikasi lain setelah kamu mengizinkan akses khusus Android.", 13, false));
        Button permission = button("Izinkan tampil di atas aplikasi lain"); root.addView(permission);
        permission.setOnClickListener(v -> requestOverlayPermission());
        Button start = button("Tampilkan Floating Window"); root.addView(start);
        start.setOnClickListener(v -> startFloating());
        Button stop = button("Tutup Floating Window"); root.addView(stop);
        stop.setOnClickListener(v -> stopService(new Intent(this, FloatingService.class)));
        status = text("Status: konfigurasi belum dihubungkan.", 14, false); status.setTextColor(Color.rgb(125,235,205)); root.addView(status);
        root.addView(text("Catatan: floating window membutuhkan izin yang kamu aktifkan sendiri di pengaturan Android. Jangan gunakan untuk merekam atau mengakses aplikasi lain tanpa izin.", 12, false));
    }
    private void loadSaved() {
        apiKeyInput.setText(prefs.getString("apiKey", ""));
        appIdInput.setText(prefs.getString("appId", ""));
        aliasInput = null;
    }
    private void connectFirebase() {
        String key = apiKeyInput.getText().toString().trim();
        String appId = appIdInput.getText().toString().trim();
        if (key.isEmpty() || appId.isEmpty()) { msg("Isi apiKey dan appId lengkap dari Firebase Config."); return; }
        try {
            prefs.edit().putString("apiKey", key).putString("appId", appId).apply();
            if (FirebaseApp.getApps(this).isEmpty()) {
                FirebaseOptions options = new FirebaseOptions.Builder()
                    .setApiKey(key)
                    .setApplicationId(appId)
                    .setProjectId("device-hub-realtime")
                    .setDatabaseUrl("https://device-hub-realtime-default-rtdb.firebaseio.com")
                    .build();
                FirebaseApp.initializeApp(this, options);
            }
            auth = FirebaseAuth.getInstance();
            FirebaseDatabase.getInstance().setPersistenceEnabled(false);
            status.setText("Firebase siap. Login atau buat akun di bawah.");
        } catch (Exception e) {
            // Firebase can already be initialized if the connect button is pressed twice.
            try { auth = FirebaseAuth.getInstance(); status.setText("Firebase siap. Login atau buat akun di bawah."); }
            catch (Exception ignored) { status.setText("Gagal menghubungkan Firebase: " + e.getMessage()); }
        }
    }
    private boolean ready() {
        if (auth == null) {
            try { auth = FirebaseAuth.getInstance(); } catch (Exception e) { msg("Tekan Simpan konfigurasi & hubungkan Firebase dulu."); return false; }
        }
        return true;
    }
    private void signUp() {
        if (!ready()) return;
        String email = emailInput.getText().toString().trim(), pass = passwordInput.getText().toString();
        if (email.isEmpty() || pass.length() < 6) { msg("Masukkan email dan kata sandi minimal 6 karakter."); return; }
        auth.createUserWithEmailAndPassword(email, pass).addOnCompleteListener(this, task -> {
            if (task.isSuccessful()) { status.setText("Akun dibuat dan login berhasil."); writePrefs(false); }
            else msg("Gagal membuat akun: " + task.getException().getMessage());
        });
    }
    private void login() {
        if (!ready()) return;
        String email = emailInput.getText().toString().trim(), pass = passwordInput.getText().toString();
        if (email.isEmpty() || pass.isEmpty()) { msg("Isi email dan kata sandi."); return; }
        auth.signInWithEmailAndPassword(email, pass).addOnCompleteListener(this, task -> {
            if (task.isSuccessful()) { status.setText("Login berhasil. Firebase aktif."); writePrefs(false); }
            else msg("Login gagal: " + task.getException().getMessage());
        });
    }
    private void writePrefs(boolean floating) {
        if (auth == null || auth.getCurrentUser() == null) return;
        String uid = auth.getCurrentUser().getUid();
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("users").child(uid).child("preferences");
        Map<String,Object> data = new HashMap<>();
        data.put("alias", "DEVICE HUB Android"); data.put("floating", floating); data.put("updatedAt", System.currentTimeMillis());
        ref.setValue(data).addOnSuccessListener(unused -> status.setText("Preferensi berhasil dikirim ke Firebase."))
           .addOnFailureListener(e -> status.setText("Gagal sinkron: " + e.getMessage()));
    }
    private void requestOverlayPermission() {
        if (Settings.canDrawOverlays(this)) { msg("Izin Floating Window sudah aktif."); return; }
        Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
        startActivity(i);
    }
    private void startFloating() {
        if (!Settings.canDrawOverlays(this)) { msg("Aktifkan izin tampil di atas aplikasi lain dulu."); requestOverlayPermission(); return; }
        Intent i = new Intent(this, FloatingService.class); startService(i);
        if (auth != null && auth.getCurrentUser() != null) writePrefs(true);
        msg("Floating Window diminta untuk ditampilkan.");
    }
    private void msg(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
}
