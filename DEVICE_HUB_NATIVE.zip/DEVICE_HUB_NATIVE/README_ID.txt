DEVICE HUB NATIVE — Floating Window Android + Firebase

ISI PROYEK
- Android native Java project.
- Floating Window memakai izin resmi Android SYSTEM_ALERT_WINDOW / TYPE_APPLICATION_OVERLAY.
- Login/buat akun Firebase Email/Password.
- Menulis alias dan status floating ke Realtime Database pada users/{uid}/preferences.

PENTING
Acode hanya editor. Acode tidak mengompilasi proyek Android menjadi APK. Untuk membangun APK, buka proyek ini di IDE Android yang mendukung Gradle/Android SDK (misalnya AndroidIDE jika masih tersedia dan kompatibel di perangkat) atau gunakan komputer dengan Android Studio. Jangan mengunduh APK dari situs tidak dikenal.

FIREBASE
Project ID: device-hub-realtime
Database URL: https://device-hub-realtime-default-rtdb.firebaseio.com
Package name Android: com.devicehub.nativeapp

1. Di Firebase Console > Project settings > Your apps > Add app > Android, daftarkan package name persis: com.devicehub.nativeapp.
2. Ikuti wizard pendaftaran Android. Ambil apiKey dan mobilesdk_app_id (appId) dari google-services.json yang diunduh untuk aplikasi Android itu. Di aplikasi ini masukkan apiKey dan mobilesdk_app_id tersebut. Jangan gunakan appId web jika sudah ada appId Android.
3. Pastikan Authentication > Sign-in method > Email/Password aktif.
4. Rules Realtime Database harus mengizinkan pengguna login hanya ke users/{uid}; aturan yang sudah dibuat sebelumnya cocok.
5. Jalankan aplikasi, masukkan apiKey dan appId Android, lalu tekan “Simpan konfigurasi & hubungkan Firebase”.
6. Buat akun atau login dengan Email/Password.
7. Tekan “Izinkan tampil di atas aplikasi lain”, aktifkan izin pada halaman Android yang terbuka, lalu kembali ke app.
8. Tekan “Tampilkan Floating Window”. Panel akan muncul di atas aplikasi lain. Geser panel dari header. Tekan × atau “Tutup panel” untuk menutupnya.

CATATAN FIREBASE
Kode memakai FirebaseOptions dari apiKey/appId web dan project/database yang ditentukan. Jika Firebase SDK menolak konfigurasi karena pengaturan proyek, daftarkan aplikasi Android di Firebase Console seperti langkah 1 dan ikuti error yang tampil. Jangan masukkan service-account JSON/private key ke aplikasi.

TARGET SDK 28 dipakai agar permintaan izin overlay sederhana pada perangkat Android modern. Izin overlay tetap harus diberikan secara manual oleh pemilik perangkat. Panel ini hanya menampilkan status lokal dan tidak membaca atau mengendalikan aplikasi lain.
