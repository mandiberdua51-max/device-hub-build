package com.devicehub.nativeapp

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val overlayRequest = 4102
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); showHome() }
    private fun showHome() {
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(36,36,36,36); setBackgroundColor(0xFF0B1020.toInt()) }
        val title = TextView(this).apply { text = "DEVICE HUB"; textSize = 28f; setTextColor(0xFFFFFFFF.toInt()); gravity = Gravity.CENTER }
        val desc = TextView(this).apply { text = "\nFloating Window Android\nPanel mini dapat tampil di atas aplikasi lain setelah izin diberikan."; textSize = 16f; setTextColor(0xFFB7C4DA.toInt()); gravity = Gravity.CENTER }
        val permission = Button(this).apply { text = "1. Izinkan Floating Window"; setOnClickListener { requestOverlayPermission() } }
        val start = Button(this).apply { text = "2. Tampilkan panel mengambang"; setOnClickListener {
            if (Settings.canDrawOverlays(this@MainActivity)) {
                val i = Intent(this@MainActivity, FloatingService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
                Toast.makeText(this@MainActivity, "Panel dimulai", Toast.LENGTH_SHORT).show()
            } else { Toast.makeText(this@MainActivity, "Aktifkan izin overlay terlebih dahulu", Toast.LENGTH_LONG).show(); requestOverlayPermission() }
        } }
        val stop = Button(this).apply { text = "Tutup panel mengambang"; setOnClickListener { stopService(Intent(this@MainActivity, FloatingService::class.java)) } }
        listOf(title,desc,permission,start,stop).forEach { v -> val p = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); p.setMargins(0,14,0,14); layout.addView(v,p) }
        setContentView(layout)
    }
    private fun requestOverlayPermission() {
        if (Settings.canDrawOverlays(this)) { Toast.makeText(this,"Izin Floating Window sudah aktif",Toast.LENGTH_SHORT).show(); return }
        startActivityForResult(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")), overlayRequest)
    }
    @Deprecated("Legacy callback supports this starter project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) { super.onActivityResult(requestCode,resultCode,data); if (requestCode == overlayRequest) Toast.makeText(this, if (Settings.canDrawOverlays(this)) "Izin berhasil aktif" else "Izin belum diaktifkan", Toast.LENGTH_SHORT).show() }
}
