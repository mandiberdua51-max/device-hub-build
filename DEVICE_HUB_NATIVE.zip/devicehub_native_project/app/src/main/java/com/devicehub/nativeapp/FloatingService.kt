package com.devicehub.nativeapp

import android.app.Notification
import android.app.NotificationChannel
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null
    override fun onCreate() {
        super.onCreate(); createNotification()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showPanel()
    }
    private fun createNotification() {
        val channelId = "device_hub_floating"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(channelId,"DEVICE HUB Floating Panel",NotificationManager.IMPORTANCE_LOW))
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this,channelId).setContentTitle("DEVICE HUB aktif").setContentText("Panel mengambang sedang berjalan").setSmallIcon(android.R.drawable.ic_menu_view).build() else @Suppress("DEPRECATION") Notification.Builder(this).setContentTitle("DEVICE HUB aktif").setContentText("Panel mengambang sedang berjalan").setSmallIcon(android.R.drawable.ic_menu_view).build()
        startForeground(21,notification)
    }
    private fun showPanel() {
        val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(28,22,28,22); setBackgroundColor(Color.rgb(25,42,68)) }
        val title = TextView(this).apply { text="DEVICE HUB MINI     × (ketuk untuk tutup)"; textSize=16f; setTextColor(Color.WHITE); setOnClickListener { stopSelf() } }
        val status = TextView(this).apply { text="\nSTATUS PERANGKAT\nONLINE\nFloating Window aktif"; textSize=16f; setTextColor(Color.WHITE) }
        val check = TextView(this).apply { text="\n[ Periksa ]"; textSize=15f; setTextColor(Color.rgb(90,220,210)); setOnClickListener { Toast.makeText(this@FloatingService,"DEVICE HUB panel aktif",Toast.LENGTH_SHORT).show() } }
        box.addView(title); box.addView(status); box.addView(check)
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply { gravity=Gravity.TOP or Gravity.START; x=24; y=160 }
        var startX=0; var startY=0; var touchX=0f; var touchY=0f
        box.setOnTouchListener { _, e -> when(e.action) { MotionEvent.ACTION_DOWN -> { startX=params.x; startY=params.y; touchX=e.rawX; touchY=e.rawY; true }; MotionEvent.ACTION_MOVE -> { params.x=startX+(e.rawX-touchX).toInt(); params.y=startY+(e.rawY-touchY).toInt(); wm.updateViewLayout(box,params); true }; else -> false } }
        panel=box; wm.addView(box,params)
    }
    override fun onDestroy() { panel?.let { try { wm.removeView(it) } catch (_:Exception) {} }; panel=null; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
