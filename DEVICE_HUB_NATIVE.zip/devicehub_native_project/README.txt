DEVICE HUB NATIVE — Floating Window starter

Proyek ini menyediakan aplikasi Android native Kotlin dengan:
- Permintaan izin Android resmi 'Display over other apps'.
- Panel mini yang dapat dipindah dan ditutup di atas aplikasi lain.
- Dependensi Firebase Authentication dan Realtime Database untuk tahap integrasi berikutnya.

PENTING:
1. Ini proyek sumber, bukan APK siap instal.
2. Acode bisa mengedit file, tetapi tidak mengompilasi APK Android sendiri.
3. Buka folder ini di Android Studio atau lingkungan build Android tepercaya.
4. Di Firebase Console, daftarkan aplikasi Android dengan package name: com.devicehub.nativeapp
5. Unduh google-services.json dari Firebase dan letakkan di folder app/ (sejajar dengan app/build.gradle).
6. Firebase SDK sudah menjadi dependensi, tetapi login dan listener sinkronisasi cloud belum diimplementasikan di starter ini. Jangan menganggap sinkronisasi native sudah aktif.
7. Pertahankan Rules Firebase yang membatasi akses per UID; jangan gunakan database publik.
8. Pengguna harus mengaktifkan izin overlay sendiri melalui Pengaturan Android.

Build:
- Buka proyek di Android Studio.
- Tambahkan app/google-services.json.
- Sync Gradle.
- Build > Build APK(s).
